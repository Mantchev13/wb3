import { Router } from 'express';
import { 
  createDisco, 
  getDiscos, 
  getDiscoById, 
  updateDisco, 
  deleteDisco 
} from '../controllers/discoController';

const router = Router();

// /api/discos
router.post('/', createDisco);
router.get('/', getDiscos);

// /api/discos/:id
router.get('/:id', getDiscoById);
router.put('/:id', updateDisco);
router.delete('/:id', deleteDisco);

export default router;