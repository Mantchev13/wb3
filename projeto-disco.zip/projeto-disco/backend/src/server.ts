import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import path from 'path';
import discoRoutes from './routes/discoRoutes';

// Configuração do App
const app = express();
const PORT = 3000;
const MONGO_URI = 'mongodb://localhost:27017/colecaoDiscos'; // Seu banco de dados

// Middlewares
app.use(cors()); // Permite requisições de origens diferentes (do frontend)
app.use(express.json()); // Permite ao Express entender JSON

// Rotas da API
app.use('/api/discos', discoRoutes); // Rota da API

// ---- ADICIONE ESTAS LINHAS ABAIXO ----

// Servir os arquivos estáticos do Frontend
// Isso assume que sua pasta 'frontend' está no mesmo nível da 'backend'
const frontendPath = path.join(__dirname, '..', '..', 'frontend');
app.use(express.static(frontendPath));

// Rota "catch-all" para servir o index.html
// Qualquer requisição GET que não seja para a API, servirá o app do frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

// Conexão com o MongoDB e Início do Servidor
mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('Conectado ao MongoDB com sucesso!');
    app.listen(PORT, () => {
      console.log(`Servidor rodando em http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Erro ao conectar ao MongoDB:', err);
  });