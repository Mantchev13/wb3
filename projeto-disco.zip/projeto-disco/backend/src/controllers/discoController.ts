import { Request, Response } from 'express';
import { Disco, IDisco } from '../models/discoModel';

// CREATE
export const createDisco = async (req: Request, res: Response) => {
  try {
    const disco: IDisco = new Disco(req.body);
    await disco.save();
    res.status(201).json(disco);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao criar disco', error });
  }
};

// READ (All)
export const getDiscos = async (req: Request, res: Response) => {
  try {
    const discos = await Disco.find();
    res.status(200).json(discos);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar discos', error });
  }
};

// READ (One by ID)
export const getDiscoById = async (req: Request, res: Response) => {
  try {
    const disco = await Disco.findById(req.params.id);
    if (!disco) return res.status(404).json({ message: 'Disco não encontrado' });
    res.status(200).json(disco);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar disco', error });
  }
};

// UPDATE
export const updateDisco = async (req: Request, res: Response) => {
  try {
    const disco = await Disco.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!disco) return res.status(404).json({ message: 'Disco não encontrado' });
    res.status(200).json(disco);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao atualizar disco', error });
  }
};

// DELETE
export const deleteDisco = async (req: Request, res: Response) => {
  try {
    const disco = await Disco.findByIdAndDelete(req.params.id);
    if (!disco) return res.status(404).json({ message: 'Disco não encontrado' });
    res.status(200).json({ message: 'Disco excluído com sucesso' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao excluir disco', error });
  }
};