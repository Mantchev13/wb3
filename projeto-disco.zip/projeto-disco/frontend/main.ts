// URL da nossa API (definida no backend)
const API_URL = 'http://localhost:3000/api/discos';

// Tipagem para os dados do disco (espelhando a Interface do backend)
interface Disco {
  _id?: string; // MongoDB usa _id
  titulo: string;
  artista: string;
  ano: number;
  genero: string;
  formato: 'Vinil' | 'CD';
  preco: number;
}

// Elementos do DOM
const form = document.getElementById('discoForm') as HTMLFormElement;
const discoIdInput = document.getElementById('discoId') as HTMLInputElement;
const tituloInput = document.getElementById('titulo') as HTMLInputElement;
const artistaInput = document.getElementById('artista') as HTMLInputElement;
const anoInput = document.getElementById('ano') as HTMLInputElement;
const generoInput = document.getElementById('genero') as HTMLInputElement;
const formatoInput = document.getElementById('formato') as HTMLSelectElement;
const precoInput = document.getElementById('preco') as HTMLInputElement;
const btnCancelar = document.getElementById('btnCancelar') as HTMLButtonElement;
const tableBody = document.getElementById('discosTbody') as HTMLTableSectionElement;

// Ao carregar a página, lista os discos
document.addEventListener('DOMContentLoaded', () => {
  listarDiscos();
});

// Event listener do formulário
form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const discoData: Disco = {
    titulo: tituloInput.value,
    artista: artistaInput.value,
    ano: parseInt(anoInput.value),
    genero: generoInput.value,
    formato: formatoInput.value as 'Vinil' | 'CD',
    preco: parseFloat(precoInput.value),
  };

  const id = discoIdInput.value;

  if (id) {
    // Se tem ID, é UPDATE (PUT)
    await fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(discoData),
    });
  } else {
    // Se não tem ID, é CREATE (POST)
    await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(discoData),
    });
  }

  resetarForm();
  await listarDiscos();
});

// Botão Cancelar Edição
btnCancelar.addEventListener('click', () => {
  resetarForm();
});

// Função para resetar o formulário
function resetarForm() {
  form.reset();
  discoIdInput.value = '';
  btnCancelar.classList.add('hidden');
}

// READ: Busca e exibe todos os discos
async function listarDiscos() {
  const response = await fetch(API_URL);
  const discos: Disco[] = await response.json();

  tableBody.innerHTML = ''; // Limpa a tabela

  discos.forEach(disco => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${disco.titulo}</td>
      <td>${disco.artista}</td>
      <td>${disco.ano}</td>
      <td>${disco.formato}</td>
      <td>R$ ${disco.preco.toFixed(2)}</td>
      <td>
        <button class="edit" onclick="prepararEdicao('${disco._id}')">Editar</button>
        <button class="delete" onclick="excluirDisco('${disco._id}')">Excluir</button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
}

// UPDATE (Parte 1): Prepara o formulário para edição
async function prepararEdicao(id: string) {
  const response = await fetch(`${API_URL}/${id}`);
  const disco: Disco = await response.json();

  // Para isto:
  discoIdInput.value = disco._id!;
  tituloInput.value = disco.titulo;
  artistaInput.value = disco.artista;
  anoInput.value = disco.ano.toString();
  generoInput.value = disco.genero;
  formatoInput.value = disco.formato;
  precoInput.value = disco.preco.toString();

  btnCancelar.classList.remove('hidden');
  window.scrollTo(0, 0); // Rola para o topo (onde está o form)
}

// DELETE: Exclui um disco
async function excluirDisco(id: string) {
  // O requisito pedia confirmação
  if (!confirm('Tem certeza que deseja excluir este disco?')) {
    return;
  }

  await fetch(`${API_URL}/${id}`, {
    method: 'DELETE',
  });

  await listarDiscos(); // Atualiza a lista
}

// Disponibiliza as funções no escopo global para o HTML (onclick)
(window as any).prepararEdicao = prepararEdicao;
(window as any).excluirDisco = excluirDisco;