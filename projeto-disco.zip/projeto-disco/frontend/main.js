var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// URL da nossa API (definida no backend)
const API_URL = 'http://localhost:3000/api/discos';
// Elementos do DOM
const form = document.getElementById('discoForm');
const discoIdInput = document.getElementById('discoId');
const tituloInput = document.getElementById('titulo');
const artistaInput = document.getElementById('artista');
const anoInput = document.getElementById('ano');
const generoInput = document.getElementById('genero');
const formatoInput = document.getElementById('formato');
const precoInput = document.getElementById('preco');
const btnCancelar = document.getElementById('btnCancelar');
const tableBody = document.getElementById('discosTbody');
// Ao carregar a página, lista os discos
document.addEventListener('DOMContentLoaded', () => {
    listarDiscos();
});
// Event listener do formulário
form.addEventListener('submit', (e) => __awaiter(void 0, void 0, void 0, function* () {
    e.preventDefault();
    const discoData = {
        titulo: tituloInput.value,
        artista: artistaInput.value,
        ano: parseInt(anoInput.value),
        genero: generoInput.value,
        formato: formatoInput.value,
        preco: parseFloat(precoInput.value),
    };
    const id = discoIdInput.value;
    if (id) {
        // Se tem ID, é UPDATE (PUT)
        yield fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(discoData),
        });
    }
    else {
        // Se não tem ID, é CREATE (POST)
        yield fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(discoData),
        });
    }
    resetarForm();
    yield listarDiscos();
}));
// Botão Cancelar Edição
btnCancelar.addEventListener('click', () => {
    resetarForm();
});
// Função para resetar o formulário
function resetarForm() {
    form.reset();
    discoIdInput.value = '';
    btnCancelar.classList.add('hidden');
}
// READ: Busca e exibe todos os discos
function listarDiscos() {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(API_URL);
        const discos = yield response.json();
        tableBody.innerHTML = ''; // Limpa a tabela
        discos.forEach(disco => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
      <td>${disco.titulo}</td>
      <td>${disco.artista}</td>
      <td>${disco.ano}</td>
      <td>${disco.formato}</td>
      <td>R$ ${disco.preco.toFixed(2)}</td>
      <td>
        <button class="edit" onclick="prepararEdicao('${disco._id}')">Editar</button>
        <button class="delete" onclick="excluirDisco('${disco._id}')">Excluir</button>
      </td>
    `;
            tableBody.appendChild(tr);
        });
    });
}
// UPDATE (Parte 1): Prepara o formulário para edição
function prepararEdicao(id) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(`${API_URL}/${id}`);
        const disco = yield response.json();
        // Para isto:
        discoIdInput.value = disco._id;
        tituloInput.value = disco.titulo;
        artistaInput.value = disco.artista;
        anoInput.value = disco.ano.toString();
        generoInput.value = disco.genero;
        formatoInput.value = disco.formato;
        precoInput.value = disco.preco.toString();
        btnCancelar.classList.remove('hidden');
        window.scrollTo(0, 0); // Rola para o topo (onde está o form)
    });
}
// DELETE: Exclui um disco
function excluirDisco(id) {
    return __awaiter(this, void 0, void 0, function* () {
        // O requisito pedia confirmação
        if (!confirm('Tem certeza que deseja excluir este disco?')) {
            return;
        }
        yield fetch(`${API_URL}/${id}`, {
            method: 'DELETE',
        });
        yield listarDiscos(); // Atualiza a lista
    });
}
// Disponibiliza as funções no escopo global para o HTML (onclick)
window.prepararEdicao = prepararEdicao;
window.excluirDisco = excluirDisco;
export {};
//# sourceMappingURL=main.js.map