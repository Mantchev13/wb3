import { Router } from 'express';
import {
    criarDespesa,
    listarDespesas,
    atualizarDespesa,
    excluirDespesa,
    obterTotalDespesas //
} from '../controllers/despesaController';

const router = Router();

// --- Rotas CRUD ---

// Rota para Criar uma nova despesa
// POST /api/despesas
router.post('/despesas', criarDespesa);

// Rota para Ler (Listar) todas as despesas
// GET /api/despesas
router.get('/despesas', listarDespesas);

// Rota para Atualizar uma despesa específica pelo ID
// PUT /api/despesas/:id
router.put('/despesas/:id', atualizarDespesa);

// Rota para Excluir uma despesa específica pelo ID
// DELETE /api/despesas/:id
router.delete('/despesas/:id', excluirDespesa);

// --- Rota Adicional (do PDF) ---

// Nova rota para obter o somatório das despesas
// GET /api/despesas/total
router.get('/despesas/total', obterTotalDespesas); //

export default router;