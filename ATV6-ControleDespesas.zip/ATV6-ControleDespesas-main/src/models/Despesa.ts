import { Schema, model, Document } from 'mongoose';

// Interface para tipagem com TypeScript
export interface IDespesa extends Document {
    descricao: string;
    valor: number;
    data: Date;
}

// Definição do Schema do Mongoose
const despesaSchema = new Schema<IDespesa>({
    descricao: {
        type: String,
        required: true,
        trim: true // Boa prática para remover espaços em branco
    },
    valor: {
        type: Number,
        required: true,
        validate: (value: number) => value >= 0 // Validação extra
    },
    data: { 
        type: Date,
        required: true,
        default: Date.now // Define data atual como padrão
    }
});

// Exporta o modelo
// O terceiro argumento ('expenses') é o nome da coleção no MongoDB 
export const Despesa = model<IDespesa>('Despesa', despesaSchema, 'expenses');