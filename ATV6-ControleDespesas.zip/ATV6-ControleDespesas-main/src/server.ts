import express, { Request, Response } from 'express';
import mongoose from 'mongoose';
import path from 'path'; // Módulo 'path' do Node.js para lidar com caminhos de arquivos
import rotasDespesas from './routes/rotasDespesas';

// Cria a aplicação Express
const app = express();
const PORTA = process.env.PORT || 3000;

// --- Middlewares ---

// 1. Middleware para o Express entender JSON
app.use(express.json());

// 2. Middleware para servir arquivos estáticos (HTML, CSS, JS)
// Ele vai servir os arquivos da pasta 'views'
app.use(express.static(path.join(__dirname, 'views')));

// --- Conexão com o MongoDB ---
// Use a sua string de conexão do MongoDB
// Lembre-se de criar o banco 'controle-despesas'
const MONGO_URI = 'mongodb://localhost:27017/controle-despesas';

mongoose.connect(MONGO_URI)
    .then(() => {
        console.log('Conectado ao MongoDB com sucesso!');

        // Inicia o servidor APÓS conectar ao banco
        app.listen(PORTA, () => {
            console.log(`Servidor rodando na porta ${PORTA} -> http://localhost:3000/`);
        });
    })
    .catch((erro) => {
        console.error('Erro ao conectar ao MongoDB:', erro);
    });

// --- Rotas da API ---
// Define um prefixo '/api' para todas as rotas de despesas
app.use('/api', rotasDespesas);

// Rota principal para servir o index.html
app.get('/', (req: Request, res: Response) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});