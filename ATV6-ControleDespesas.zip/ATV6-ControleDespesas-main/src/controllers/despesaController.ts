import { Request, Response } from 'express';
import { Despesa, IDespesa } from '../models/Despesa';

// Criar: Inserir nova despesa
export const criarDespesa = async (req: Request, res: Response) => {
    try {
        const { descricao, valor, data } = req.body;

        // Validação simples de campos vazios
        if (!descricao || valor == null || !data) {
            return res.status(400).json({ erro: 'Campos obrigatórios estão faltando.' });
        }

        // Validação de valor negativo
        if (valor < 0) {
            return res.status(400).json({ erro: 'O valor não pode ser negativo.' });
        }

        const novaDespesa = new Despesa({
            descricao,
            valor,
            data: new Date(data) // Garante que a data seja um objeto Date
        });

        await novaDespesa.save();
        res.status(201).json(novaDespesa);
    } catch (erro) {
        res.status(500).json({ erro: 'Erro ao criar a despesa.' });
    }
};

// Ler: Listar todas as despesas
export const listarDespesas = async (req: Request, res: Response) => {
    try {
        const despesas = await Despesa.find().sort({ data: -1 }); // Ordena pelas mais recentes
        res.status(200).json(despesas);
    } catch (erro) {
        res.status(500).json({ erro: 'Erro ao buscar as despesas.' });
    }
};

// Atualizar: Atualizar uma despesa 
export const atualizarDespesa = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { descricao, valor, data } = req.body;

        const despesaAtualizada = await Despesa.findByIdAndUpdate(
            id,
            { descricao, valor, data },
            { new: true, runValidators: true } // 'new: true' retorna o doc atualizado
        );

        if (!despesaAtualizada) {
            return res.status(404).json({ erro: 'Despesa não encontrada.' });
        }
        res.status(200).json(despesaAtualizada);
    } catch (erro) {
        res.status(500).json({ erro: 'Erro ao atualizar a despesa.' });
    }
};

// Excluir: Remover uma despesa 
export const excluirDespesa = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const despesaExcluida = await Despesa.findByIdAndDelete(id);

        if (!despesaExcluida) {
            return res.status(404).json({ erro: 'Despesa não encontrada.' });
        }
        res.status(200).json({ mensagem: 'Despesa excluída com sucesso.' });
    } catch (erro) {
        res.status(500).json({ erro: 'Erro ao excluir a despesa.' });
    }
};

// --- Função fornecida no PDF ---

// Função para obter o somatório das despesas [cite: 87]
export const obterTotalDespesas = async (req: Request, res: Response) => {
    try {
        const total = await Despesa.aggregate([ 
            {
                $group: { 
                    _id: null, 
                    totalAmount: { $sum: "$valor" } 
                }
            }
        ]);

        // Caso não haja despesas, retornar total 0 
        const totalAmount = total.length > 0 ? total[0].totalAmount : 0;
        res.json({ totalAmount }); 
    } catch (erro) {
        res.status(500).json({ erro: 'Erro ao calcular o total das despesas' }); 
    }
};